---
abstract: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum. Sed
  ac faucibus dolor, scelerisque sollicitudin nisi. Cras purus urna, suscipit quis
  sapien eu, pulvinar tempor diam. Quisque risus orci, mollis id ante sit amet, gravida
  egestas nisl. Sed ac tempus magna. Proin in dui enim. Donec condimentum, sem id
  dapibus fringilla, tellus enim condimentum arcu, nec volutpat est felis vel metus.
  Vestibulum sit amet erat at nulla eleifend gravida.
authors:
- admin
date: "2019-04-07T00:00:00+02:00"
doi: ""
featured: false
image:
  caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/s9CC2SKySJM)'
  focal_point: ""
projects: []
publication: ""
publication_short: ""
publication_types:
- "3"
slides: ""
summary: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum.
tags:
- Source Themes
title: An example preprint / working paper
url_code: ""
url_dataset: ""
url_pdf: http://arxiv.org/pdf/1512.04133v1
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
---

{{% alert note %}}
Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/).
{{% /alert %}}
